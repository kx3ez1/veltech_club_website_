from flask import Flask, request, render_template, url_for, make_response, redirect, session, flash
from flask_recaptcha import ReCaptcha
from encrypt import encrypt_data, decrypt_data
import json

app = Flask(__name__)
recaptcha = ReCaptcha(app=app)
app.config.update(dict(
    RECAPTCHA_ENABLED=True,
    RECAPTCHA_SITE_KEY="6LfPqY0aAAAAAMF_cUbfJqFKgXb1f5zFewio71jn",
    RECAPTCHA_SECRET_KEY="6LfPqY0aAAAAAKsM6pEw_bEl7RJy36Y7YG7REZIa",
))
recaptcha = ReCaptcha()
recaptcha.init_app(app)
app.secret_key = 'nikhil musunuri'


def clean(data):
    data = data.replace('<', '&lt;')
    data = data.replace('>', '&gt;')
    return data


def insert_into_database(username, password):
    return True


def chk_user_in_database(username, password):
    return True


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        data = request.form
        c_user = clean(request.form['username'])
        c_pass = clean(request.form['password'])
        if insert_into_database(c_user, c_pass):
            resp = make_response(redirect('/dashboard'))
            login_data = {
                'username': c_user,
                'password': c_pass
            }
            encrypted_data = encrypt_data(json.dumps(login_data))
            print(encrypted_data)
            resp.set_cookie("nikhil", str(encrypted_data))
            session['username'] = request.form['username']
            return resp
        else:
            return "check username or password"
    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == "POST":
        data = request.form
        c_user = clean(request.form['username'])
        c_pass = clean(request.form['password'])
        if chk_user_in_database(c_user, c_pass):
            return "Successfully Logged.."
        else:
            return "user already Registered ..<br> <a href='/forgot_password'>Try forgot password</a>"
    return render_template('signup.html')


@app.route('/')
@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        username = session['username']
        return render_template('dashboard.html', username=username)
    else:
        return redirect('/login')


@app.route('/gallery')
def gallery():
    if 'username' in session:
        username = session['username']
        return render_template('gallery.html', username=username)
    else:
        return redirect('/login')


@app.route('/contact')
def contact():
    if 'username' in session:
        username = session['username']
        return render_template('contact.html', username=username)
    else:
        return redirect('/login')


@app.route('/about')
def about():
    if 'username' in session:
        username = session['username']
        return render_template('about.html', username=username)
    else:
        return redirect('/login')


@app.route('/logout')
def logout():
    session.pop('username', None)
    return render_template('logout.html')


@app.route('/submit', methods=['POST'])
def submit():
    if recaptcha.verify():
        return redirect(url_for('login'), code=307)
    else:
        flash('Error ReCaptcha')
        return redirect(url_for('login'))


@app.route('/submit2', methods=['POST'])
def submit2():
    if recaptcha.verify():
        return redirect(url_for('signup'), code=307)
    else:
        flash('Error ReCaptcha')
        return redirect(url_for('signup'))


if __name__ == "__main__":
    app.run(debug=True)
