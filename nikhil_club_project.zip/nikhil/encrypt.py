def encrypt_data(data):
    from cryptography.fernet import Fernet
    key = Fernet.generate_key()
    print(key)
    fernet2 = Fernet(key)
    return fernet2.encrypt(data.encode())


def decrypt_data(key, data):
    from cryptography.fernet import Fernet,InvalidToken
    fernet1 = Fernet(key)
    try:
        return fernet1.decrypt(data).decode()
    except InvalidToken:
        return None
