def check_cookie(req):
    username = req.cookies.get('username')
    password = req.cookies.get('password')
    print('@@ ==> ',username,password)
    if login(username,password) == 200:
        return True
    else:
        return False
